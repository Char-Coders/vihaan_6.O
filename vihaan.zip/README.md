# vihaan_6.O
vihaan project

## First Time install commands

```cmd
cd frontend && npm install
cd ..\backend && npm install
cd .. && npm start
```
